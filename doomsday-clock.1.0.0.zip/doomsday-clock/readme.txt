=== Doomsday Clock ===

Contributors:      thebigdotco
Plugin Name:       Doomsday Clock
Plugin URI:        https://howmanyminutestomidnight.com/
Tags:              doomsday clock, clock, doomsday
Author URI:        https://thebig.co
Author:            The Big Dot Company
Requires PHP:      5.2
Requires at least: 2.3
Tested up to:      5.2.2
Stable tag:        1.0.0
Version:           1.0.0

== Description ==
Embed a live Doomsday clock on your WordPress website using a widget or a Shortcode. The clock will always display the current time according to the Bulletin of Atomic Scientists.

You can choose between the modern (c2012) style clock, and the classic 1947 style clock. You can change the colour of the clock using the widget or the shortcode.

== Installation ==
1. Find the plugin in the list at the backend and click to install it. Or, upload the ZIP file through the admin backend. Or, upload the unzipped tag-groups folder to the /wp-content/plugins/ directory.

2. Activate the plugin through the 'Plugins' menu in WordPress.


== Screenshots ==
1. The customisable widget

== Changelog ==
This is the first version

== 3rd Party Services ==
The plugin reads the current time from the 3rd party service: <a href="https://howmanyminutestomidnight.com">howmanyminutestomidnight.com</a>

The Terms of Service for the above website can be found <a target="_blank" href="https://howmanyminutestomidnight.com/terms-of-service/">here</a>.


== Frequently Asked Questions ==
= How do I use the clock?
The clock can be inserted into your site using a widget or a Shortcode

= How do I customise the clock?
The clock can be customised in the widget or by using the Shortcode. The parameters for the shortcode are:

text=true or false (displays the time in text below the clock)
design=modern or classic (modern or 1947 style clock)
colour=#e1e1e1 (any hexadecimal colour code)
Example code:  [doomsday text=true design=classic colour=#e1e1e1]


== Donations ==
We don't want donations, but if you enjoy the plugin, please consider <a target="_blank" href="https://thebulletin.org/giving-donate/">donating</a> to the Bulletin of the Atomic Scientists.