<?php
/*
Plugin Name: Doomsday clock
Plugin URI: https://howmanyminutestomidnight.com/
Description: Embed a live Doomsday clock on your WordPress website.
Author: The Big Dot Company
Version: 1.0.0
Author URI: https://thebig.co/

*/


if (!class_exists('simple_html_dom_node')) {
    require_once plugin_dir_path(__FILE__).'simple_html_dom.php';
}

if (!class_exists('bdc_doomsday_clock_wpb_widget')) {
    require_once plugin_dir_path(__FILE__).'widget.php';
}




/*function bdc_requestUrl($url, $proxy = NULL) {
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, $url);
	if ($proxy != NULL) {
		curl_setopt($curl, CURLOPT_PROXY, $proxy);
	}
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1) Gecko/20061204 Firefox/2.0.0.1");
	
	curl_setopt($curl, CURLOPT_FOLLOWLOCATION,1);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl, CURLOPT_ENCODING, "");
	$contents = curl_exec($curl);
	curl_close($curl);
	return $contents;
}*/


function bdc_get_doomsday_clock_minut_in_midnight_modern(){
 if (class_exists('simple_html_dom')) {
	$html = new simple_html_dom();
	//$html_data = bdc_requestUrl('https://howmanyminutestomidnight.com/'); 
	$responce = wp_remote_get( 'https://howmanyminutestomidnight.com/' );
	$html_data = $responce['body'];
	
	
	$minuts_midnight_value = false;
	if($html_data){
		$html->load($html_data);
		$count = 1;
		foreach($html->find('.ddinner h2 span') as $minuts_midnight_content){
			if($count == 2){
				$minuts_midnight_value = ucfirst(trim(strip_tags($minuts_midnight_content->innertext))); 
			}
			$count++;
		}
	}
	
	$minuts_image_data = array(
									array( 
										'image' => 'MTM_0.svg',
										'time' => 'It is midnight'
									),
									array( 
										'image' => 'MTM_0H.svg',
										'time' => 'It is half a minute to midnight'
									),
									array( 
										'image' => 'MTM_1.svg',
										'time' => 'It is 1 minutes to midnight'
									),
									array( 
										'image' => 'MTM_1H.svg',
										'time' => 'It is 1 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_2.svg',
										'time' => 'It is 2 minutes to midnight'
									),
									array( 
										'image' => 'MTM_2H.svg',
										'time' => 'It is 2 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_3.svg',
										'time' => 'It is 3 minutes to midnight'
									),
									array( 
										'image' => 'MTM_3H.svg',
										'time' => 'It is 3 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_4.svg',
										'time' => 'It is 4 minutes to midnight'
									),
									array( 
										'image' => 'MTM_4H.svg',
										'time' => 'It is 4 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_5.svg',
										'time' => 'It is 5 minutes to midnight'
									),
									array( 
										'image' => 'MTM_5H.svg',
										'time' => 'It is 5 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_6.svg',
										'time' => 'It is 6 minutes to midnight'
									),
									array( 
										'image' => 'MTM_6H.svg',
										'time' => 'It is 6 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_7.svg',
										'time' => 'It is 7 minutes to midnight'
									),
									array( 
										'image' => 'MTM_7H.svg',
										'time' => 'It is 7 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_8.svg',
										'time' => 'It is 8 minutes to midnight'
									),
									array( 
										'image' => 'MTM_8H.svg',
										'time' => 'It is 8 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_9.svg',
										'time' => 'It is 9 minutes to midnight'
									),
									array( 
										'image' => 'MTM_9H.svg',
										'time' => 'It is 9 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_10.svg',
										'time' => 'It is 10 minutes to midnight'
									),
									array( 
										'image' => 'MTM_10H.svg',
										'time' => 'It is 10 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_11.svg',
										'time' => 'It is 11 minutes to midnight'
									),
									array( 
										'image' => 'MTM_11H.svg',
										'time' => 'It is 11 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_12.svg',
										'time' => 'It is 12 minutes to midnight'
									),
									array( 
										'image' => 'MTM_12H.svg',
										'time' => 'It is 12 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_13.svg',
										'time' => 'It is 13 minutes to midnight'
									),
									array( 
										'image' => 'MTM_13H.svg',
										'time' => 'It is 13 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_14.svg',
										'time' => 'It is 14 minutes to midnight'
									),
									array( 
										'image' => 'MTM_14H.svg',
										'time' => 'It is 14 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_15.svg',
										'time' => 'It is 15 minutes to midnight'
									),
									array( 
										'image' => 'MTM_15H.svg',
										'time' => 'It is 15 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_16.svg',
										'time' => 'It is 16 minutes to midnight'
									),
									array( 
										'image' => 'MTM_16H.svg',
										'time' => 'It is 16 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_17.svg',
										'time' => 'It is 17 minutes to midnight'
									),
									array( 
										'image' => 'MTM_17H.svg',
										'time' => 'It is 17 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_18.svg',
										'time' => 'It is 18 minutes to midnight'
									),
									array( 
										'image' => 'MTM_18H.svg',
										'time' => 'It is 18 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_19.svg',
										'time' => 'It is 19 minutes to midnight'
									),
									array( 
										'image' => 'MTM_19H.svg',
										'time' => 'It is 19 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_20.svg',
										'time' => 'It is 20 minutes to midnight'
									),
									array( 
										'image' => 'MTM_0.svg',
										'time' => 'It is still midnight'
									),
									array( 
										'image' => 'MTM_0H.svg',
										'time' => 'It is still half a minute to midnight'
									),
									array( 
										'image' => 'MTM_1.svg',
										'time' => 'It is still 1 minutes to midnight'
									),
									array( 
										'image' => 'MTM_1H.svg',
										'time' => 'It is still 1 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_2.svg',
										'time' => 'It is still 2 minutes to midnight'
									),
									array( 
										'image' => 'MTM_2H.svg',
										'time' => 'It is still 2 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_3.svg',
										'time' => 'It is still 3 minutes to midnight'
									),
									array( 
										'image' => 'MTM_3H.svg',
										'time' => 'It is still 3 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_4.svg',
										'time' => 'It is still 4 minutes to midnight'
									),
									array( 
										'image' => 'MTM_4H.svg',
										'time' => 'It is still 4 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_5.svg',
										'time' => 'It is still 5 minutes to midnight'
									),
									array( 
										'image' => 'MTM_5H.svg',
										'time' => 'It is 5 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_6.svg',
										'time' => 'It is still 6 minutes to midnight'
									),
									array( 
										'image' => 'MTM_6H.svg',
										'time' => 'It is still 6 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_7.svg',
										'time' => 'It is still 7 minutes to midnight'
									),
									array( 
										'image' => 'MTM_7H.svg',
										'time' => 'It is still 7 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_8.svg',
										'time' => 'It is still 8 minutes to midnight'
									),
									array( 
										'image' => 'MTM_8H.svg',
										'time' => 'It is still 8 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_9.svg',
										'time' => 'It is still 9 minutes to midnight'
									),
									array( 
										'image' => 'MTM_9H.svg',
										'time' => 'It is still 9 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_10.svg',
										'time' => 'It is still 10 minutes to midnight'
									),
									array( 
										'image' => 'MTM_10H.svg',
										'time' => 'It is still 10 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_11.svg',
										'time' => 'It is 11 minutes to midnight'
									),
									array( 
										'image' => 'MTM_11H.svg',
										'time' => 'It is still 11 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_12.svg',
										'time' => 'It is still 12 minutes to midnight'
									),
									array( 
										'image' => 'MTM_12H.svg',
										'time' => 'It is still 12 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_13.svg',
										'time' => 'It is still 13 minutes to midnight'
									),
									array( 
										'image' => 'MTM_13H.svg',
										'time' => 'It is still 13 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_14.svg',
										'time' => 'It is still 14 minutes to midnight'
									),
									array( 
										'image' => 'MTM_14H.svg',
										'time' => 'It is still 14 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_15.svg',
										'time' => 'It is still 15 minutes to midnight'
									),
									array( 
										'image' => 'MTM_15H.svg',
										'time' => 'It is still 15 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_16.svg',
										'time' => 'It is still 16 minutes to midnight'
									),
									array( 
										'image' => 'MTM_16H.svg',
										'time' => 'It is still 16 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_17.svg',
										'time' => 'It is still 17 minutes to midnight'
									),
									array( 
										'image' => 'MTM_17H.svg',
										'time' => 'It is still 17 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_18.svg',
										'time' => 'It is still 18 minutes to midnight'
									),
									array( 
										'image' => 'MTM_18H.svg',
										'time' => 'It is still 18 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_19.svg',
										'time' => 'It is still 19 minutes to midnight'
									),
									array( 
										'image' => 'MTM_19H.svg',
										'time' => 'It is still 19 and a half minutes to midnight'
									),
									array( 
										'image' => 'MTM_20.svg',
										'time' => 'It is still 20 minutes to midnight'
									)	
								);
	
	if($minuts_midnight_value){
		foreach($minuts_image_data as $minuts_image_extract){
			if($minuts_image_extract['time'] == $minuts_midnight_value){
				return $minuts_image_extract;
				break;
			}
		}
	}
	
	return false;
	/*if($minuts_midnight_value){
		//$minuts_midnight_value = 'It is 2 and a half minutes to midnight';
		preg_match('/(?:(\d+)|(1|2|3|4|5|6|7|8|9)(.*?half)) minutes to midnight/i', $minuts_midnight_value, $matches);
		print_r($matches);
		if ($matches) {
			if (!is_nan($matches[1]))
				return $result[1];
			if ($matches[2]) {
				echo $whole = bdcnumberStringToInt($matches[2]);
				if (!is_nan($whole))
					return $whole + 0.5;
			}
		}
	}
	*/
}
}


//duplicate

function bdc_get_doomsday_clock_minut_in_midnight_classic(){
  if (class_exists('simple_html_dom')) {
	$html = new simple_html_dom();
	$responce = wp_remote_get( 'https://howmanyminutestomidnight.com/' );
	$html_data = $responce['body'];
	
	$minuts_midnight_value = false;
	if($html_data){
		$html->load($html_data);
		$count = 1;
		foreach($html->find('.ddinner h2 span') as $minuts_midnight_content){
			if($count == 2){
				$minuts_midnight_value = ucfirst(trim(strip_tags($minuts_midnight_content->innertext))); 
			}
			$count++;
		}
	}
	
	$minuts_image_data = array(
									array( 
										'image' => 'C_CMTM0.svg',
										'time' => 'It is midnight'
									),
									array( 
										'image' => 'C_CMTM0H.svg',
										'time' => 'It is half a minute to midnight'
									),
									array( 
										'image' => 'C_CMTM1.svg',
										'time' => 'It is 1 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM1H.svg',
										'time' => 'It is 1 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM2.svg',
										'time' => 'It is 2 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM2H.svg',
										'time' => 'It is 2 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM3.svg',
										'time' => 'It is 3 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM3H.svg',
										'time' => 'It is 3 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM4.svg',
										'time' => 'It is 4 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM4H.svg',
										'time' => 'It is 4 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM5.svg',
										'time' => 'It is 5 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM5H.svg',
										'time' => 'It is 5 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM6.svg',
										'time' => 'It is 6 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM6H.svg',
										'time' => 'It is 6 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM7.svg',
										'time' => 'It is 7 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM7H..svg',
										'time' => 'It is 7 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM8.svg',
										'time' => 'It is 8 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM8H.svg',
										'time' => 'It is 8 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM9.svg',
										'time' => 'It is 9 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM9H.svg',
										'time' => 'It is 9 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM10.svg',
										'time' => 'It is 10 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM10H.svg',
										'time' => 'It is 10 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM11.svg',
										'time' => 'It is 11 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM11H.svg',
										'time' => 'It is 11 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM12.svg',
										'time' => 'It is 12 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM12H.svg',
										'time' => 'It is 12 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM13.svg',
										'time' => 'It is 13 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM13H.svg',
										'time' => 'It is 13 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM14.svg',
										'time' => 'It is 14 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM14H.svg',
										'time' => 'It is 14 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM15.svg',
										'time' => 'It is 15 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM15H.svg',
										'time' => 'It is 15 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM16.svg',
										'time' => 'It is 16 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM16H.svg',
										'time' => 'It is 16 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM17.svg',
										'time' => 'It is 17 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM17H.svg',
										'time' => 'It is 17 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM18.svg',
										'time' => 'It is 18 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM18H.svg',
										'time' => 'It is 18 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM19.svg',
										'time' => 'It is 19 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM19H.svg',
										'time' => 'It is 19 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM20.svg',
										'time' => 'It is 20 minutes to midnight' 
									),
									
									// still data image
									
									array( 
										'image' => 'C_CMTM0.svg',
										'time' => 'It is still midnight'
									),
									array( 
										'image' => 'C_CMTM0H.svg',
										'time' => 'It is still half a minute to midnight'
									),
									array( 
										'image' => 'C_CMTM1.svg',
										'time' => 'It is still 1 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM1H.svg',
										'time' => 'It is still 1 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM2.svg',
										'time' => 'It is still 2 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM2H.svg',
										'time' => 'It is still 2 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM3.svg',
										'time' => 'It is still 3 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM3H.svg',
										'time' => 'It is still 3 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM4.svg',
										'time' => 'It is still 4 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM4H.svg',
										'time' => 'It is still 4 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM5.svg',
										'time' => 'It is still 5 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM5H.svg',
										'time' => 'It is 5 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM6.svg',
										'time' => 'It is still 6 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM6H.svg',
										'time' => 'It is still 6 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM7.svg',
										'time' => 'It is still 7 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM7H.svg',
										'time' => 'It is still 7 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM8.svg',
										'time' => 'It is still 8 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM8H.svg',
										'time' => 'It is still 8 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM9.svg',
										'time' => 'It is still 9 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM9H.svg',
										'time' => 'It is still 9 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM10.svg',
										'time' => 'It is still 10 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM10H.svg',
										'time' => 'It is still 10 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM11.svg',
										'time' => 'It is 11 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM11H.svg',
										'time' => 'It is still 11 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM12.svg',
										'time' => 'It is still 12 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM12H.svg',
										'time' => 'It is still 12 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM13.svg',
										'time' => 'It is still 13 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM13H.svg',
										'time' => 'It is still 13 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM14.svg',
										'time' => 'It is still 14 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM14H.svg',
										'time' => 'It is still 14 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM15.svg',
										'time' => 'It is still 15 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM15H.svg',
										'time' => 'It is still 15 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM16.svg',
										'time' => 'It is still 16 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM16H.svg',
										'time' => 'It is still 16 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM17.svg',
										'time' => 'It is still 17 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM17H.svg',
										'time' => 'It is still 17 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM18.svg',
										'time' => 'It is still 18 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM18H.svg',
										'time' => 'It is still 18 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM19.svg',
										'time' => 'It is still 19 minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM19H.svg',
										'time' => 'It is still 19 and a half minutes to midnight'
									),
									array( 
										'image' => 'C_CMTM20.svg',
										'time' => 'It is still 20 minutes to midnight'
									)	
								);
	
	if($minuts_midnight_value){
		foreach($minuts_image_data as $minuts_image_extract){
			if($minuts_image_extract['time'] == $minuts_midnight_value){
				return $minuts_image_extract;
				break;
			}
		}
	}
	
	return false;
	/*if($minuts_midnight_value){
		//$minuts_midnight_value = 'It is 2 and a half minutes to midnight';
		preg_match('/(?:(\d+)|(1|2|3|4|5|6|7|8|9)(.*?half)) minutes to midnight/i', $minuts_midnight_value, $matches);
		print_r($matches);
		if ($matches) {
			if (!is_nan($matches[1]))
				return $result[1];
			if ($matches[2]) {
				echo $whole = bdcnumberStringToInt($matches[2]);
				if (!is_nan($whole))
					return $whole + 0.5;
			}
		}
	}
	*/
}
}


function bdcnumberStringToInt($value){
    switch (strtolower($value)) {
        case 'one': 
			return 1;
        case 'two': 
			return 2;
        case 'three': 
			return 3;
        case 'four': 
			return 4;
        case 'five': 
			return 5;
        case 'six': 
			return 6;
        case 'seven': 
			return 7;
        case 'eight': 
			return 8;
        case 'nine': 
			return 9;
    }
    return NAN;
}




function bdc_doomsday_clock_shortcode($atts) {
	
	$shortcode_data = shortcode_atts( array(
        'colour' => '',
        'text'  =>  'true',
        'design' =>  'modern',
		'id' => '0'
      
    ), $atts );

   $colour =  $shortcode_data['colour']; 
   $text =  $shortcode_data['text'];
   $design =  $shortcode_data['design'];
   $id =  $shortcode_data['id'];
   
	ob_start();
  
  
if($design == 'modern'){
	       if (function_exists('bdc_get_doomsday_clock_minut_in_midnight_modern')) {
			   $clock_data = bdc_get_doomsday_clock_minut_in_midnight_modern();
		   }
		}
		else if($design == 'classic'){
	        if (function_exists('bdc_get_doomsday_clock_minut_in_midnight_classic')) {
				$clock_data = bdc_get_doomsday_clock_minut_in_midnight_classic();
			}
		}
		
	if(!empty($clock_data)){
		
		if($colour){ ?>
			<style>
            #bdc_mtmclock <?php echo $id;?> circle {
            fill: <?php echo $colour; ?>;
            } 
            #bdc_mtmclock<?php echo $id;?> path{
            fill: <?php echo $colour; ?>;
            }
            #bdc_mtmclock<?php echo $id;?> polygon{
            fill: <?php echo $colour; ?>;
            }
            #bdc_mtmclock<?php echo $id;?> rect{
            fill: <?php echo $colour; ?>;
            }
            </style>

			<?php
			
		}
		echo'<div style="text-align:center;">';
		echo '<img  src="'.plugin_dir_url( __FILE__ ) . 'images/'.$clock_data['image'].'" id="bdc_mtmclock'.$id.'" class="svg" style="height:330px; ">';
		echo'</div>';
		if($text == 'true'){
			echo '<p style="text-align: center;font-weight: bold;font-size:18px; color:'.$colour.';">'.$clock_data['time'].'</p>';
		}
	}
	
	$output = ob_get_contents();
	ob_get_clean();
	return $output;
}

add_shortcode('doomsday', 'bdc_doomsday_clock_shortcode');


add_action('wp_head', 'bdc_color_change_svg');
 

function bdc_color_change_svg(){ 
wp_enqueue_scripts('jquery');
?>
<script>
jQuery(function () {
  jQuery("img.svg").each(function () {
    var jQueryimg = jQuery(this);
    var attributes = jQueryimg.prop("attributes");
    var imgURL = jQueryimg.attr("src");
    jQuery.get(imgURL, function (data) {
      var jQuerysvg = jQuery(data).find('svg');
      jQuerysvg = jQuerysvg.removeAttr('xmlns:a');
      jQuery.each(attributes, function() {
        jQuerysvg.attr(this.name, this.value);
      });
      jQueryimg.replaceWith(jQuerysvg);
    });
  });
});
</script>
<?php 
}


	
	