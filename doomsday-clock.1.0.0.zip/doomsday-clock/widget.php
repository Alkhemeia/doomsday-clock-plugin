<?php 
	// Register and load the widget
function bdc_wpb_load_widget() {
    register_widget( 'bdc_doomsday_clock_wpb_widget' );
}
add_action( 'widgets_init', 'bdc_wpb_load_widget' );

// Creating the widget 
if (class_exists('WP_Widget')) {
class bdc_doomsday_clock_wpb_widget extends WP_Widget {
 
	function __construct() {
		parent::__construct( 'wpb_widget',  __('Doomsday Clock', 'wpb_widget_domain'), 
	 
		// Widget description
		array( 'description' => __( 'Widget display doomsday clock', 'wpb_widget_domain' ), ) );
	}
 
 
	public function widget( $args, $instance ) {
		
	//	if($instance['title'] != ""){
	//		$instance['title'] = date('Y')." " .$instance['title'];
	//	}
		
	    $bgcolor = $instance['clockcolor'];
		$checkbox = $instance['bdc_chose_to_display_time']; 
		
		$title = apply_filters( 'widget_title', $instance['title'] ); 
		 
		// before and after widget arguments are defined by themes
		echo $args['before_widget'];
		if ( ! empty( $title ) )
		echo $args['before_title'] . $title . $args['after_title']; 
		
		$clock_type = $instance['bdc_clocktype']; 
		
		if($clock_type == 'Modern_Clock'){
			if (function_exists('bdc_get_doomsday_clock_minut_in_midnight_modern')) {
			   $clock_data = bdc_get_doomsday_clock_minut_in_midnight_modern();
			}
		}
		else if($clock_type == 'Classic_Clock'){
			if (function_exists('bdc_get_doomsday_clock_minut_in_midnight_classic')) {
				$clock_data = bdc_get_doomsday_clock_minut_in_midnight_classic();
			}
		}
		 
		// This is where you run the code and display the output
		//echo __( 'Doomsday Clock', 'wpb_widget_domain' );
		
		
		if(!empty($clock_data)){
			$stylebg = '';	
			if($bgcolor){ ?>
<style>
	#mtmclock circle {
	fill: <?php echo $bgcolor; ?>;
	} 
	#mtmclock path{
	fill: <?php echo $bgcolor; ?>;
	}
	#mtmclock polygon{
	fill: <?php echo $bgcolor; ?>;
	}
	#mtmclock rect{
	fill: <?php echo $bgcolor; ?>;
	}
</style>

				<?php
				
				//$stylebg = 'style="background:'.$bgcolor.'; fill:'.$bgcolor.';"';	
			}
			echo '<img  src="'.plugin_dir_url( __FILE__ ) . 'images/'.$clock_data['image'].'" id="mtmclock" class="svg">';
			if($checkbox){
				echo '<p style="text-align: center;font-weight: bold;font-size:18px; color:'.$bgcolor.';">'.$clock_data['time'].'</p>';
			}
		}
		echo $args['after_widget'];
		
	}
         
	// Widget Backend 
	public function form( $instance ) {
		if ( isset( $instance[ 'title' ] ) ) {
			$title = $instance[ 'title' ]; 
		}
		
		if ( isset( $instance[ 'clockcolor' ] ) ) {
			$clockcolor = $instance[ 'clockcolor' ]; 
		}
		
		else {
		$title = __( 'Title', 'wpb_widget_domain' );
		}
		
		$checkbox = $instance['bdc_chose_to_display_time']; 
		// Widget admin form
		?>
		<p>
		<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
        <p>
        <label for="<?php echo $this->get_field_id( 'clockcolor' ); ?>"><?php _e( 'Clock Color:' ); ?></label> 
        <input style="width: 80px;vertical-align: middle;" class="widefat" id="<?php echo $this->get_field_id( 'clockcolor' ); ?>" name="<?php echo $this->get_field_name( 'clockcolor' ); ?>" type="color" value="<?php echo esc_attr( $clockcolor ); ?>" />
        </p>
        
        <p>
        <label for="<?php echo $this->get_field_id( 'bdc_chose_to_display_time' ); ?>"><?php _e( 'Choose To Display Time:' ); ?></label> 
        <input type="checkbox" name="<?php echo $this->get_field_name( 'bdc_chose_to_display_time' ); ?>" value="1" <?php if($checkbox == 1){echo "checked";}?>/>
        </p>
        
        <p>
        <label for="<?php echo $this->get_field_id( 'bdc_clocktype' ); ?>"><?php _e( 'Choose Clock Type:' ); ?></label> 
      <select id="<?php echo $this->get_field_id('bdc_clocktype'); ?>" name="<?php echo $this->get_field_name('bdc_clocktype'); ?>" class="widefat" style="width:100%;">
    		 <option <?php selected( $instance['bdc_clocktype'], 'Classic_Clock'); ?> value="Classic_Clock">Classic Clock</option>
   			 <option <?php selected( $instance['bdc_clocktype'], 'Modern_Clock'); ?> value="Modern_Clock">Modern Clock</option> 
	  </select>
        </p>
        
		<?php 
	}
     
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['clockcolor'] = ( ! empty( $new_instance['clockcolor'] ) ) ? strip_tags( $new_instance['clockcolor'] ) : '';
		$instance['bdc_chose_to_display_time'] = ( ! empty( $new_instance['bdc_chose_to_display_time'] ) ) ? strip_tags( $new_instance['bdc_chose_to_display_time'] ) : '';
		
		$instance['bdc_clocktype'] = ( ! empty( $new_instance['bdc_clocktype'] ) ) ? strip_tags( $new_instance['bdc_clocktype'] ) : '';
		
		return $instance;
	}
}
}